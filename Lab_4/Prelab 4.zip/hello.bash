#!/bin/bash
# hello.bash

echo -n "Please tell me your name (first, Last):"
read -r fullname
echo "Hello $fullname"
