double degreeToOnDelay(double degree) {
	return degree * 10 + 600;
}